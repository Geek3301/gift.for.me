package org.nantipov.utils.wordhugopress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class WordHugoPressApplicationTests {

    @Test
    public void contextLoads() {

    }
}
