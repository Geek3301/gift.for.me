package main

import "github.com/ashishb/wp2hugo/src/wp2hugo/cmd/hugomanager/cmd"

func main() {
	cmd.Execute()
}
